package com.example.foodorderapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.foodorderapp.Models.OrdersModel;

import java.util.ArrayList;

public class DBhelper extends SQLiteOpenHelper {
   final static String DBNAME ="mydatabase.db";
   final static int DBVERSION =2;
    public DBhelper(@Nullable Context context) {
        super(context, DBNAME, null, DBVERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
       sqLiteDatabase.execSQL(
               "create table orders" +
                       "(id integer primary key autoIncrement," +
                        "name text," +
                        "phone text," +
                        "price int,"+
                       "quantity int,"+
                        "image int," +
                        "description text," +
                        "foodname text)"


               /*id=1
                 name=2
                 phone=3
                 price=4
                 quantity=5
                 image=6
                 descreption =7
                 foodname=8*/

       );


    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL("DROP table if exists orders");
        onCreate(sqLiteDatabase);

    }
    public boolean inserOrder(String name,String phone, int price, int image, String desc, String foodName, int quantity){
        SQLiteDatabase database = getReadableDatabase();
        ContentValues values =new ContentValues();
        values.put("name", name);
        values.put("phone", phone);
        values.put("name", price);
        values.put("image", image);
        values.put("Description", desc);
        values.put("foodname", foodName);
        values.put("quantity", quantity);
       long id = database.insert("orders",null,values);
       if(id <= 0){
           return false;
       }
       return true;
    }
    public ArrayList<OrdersModel> getOrders(){
        ArrayList<OrdersModel> orders = new ArrayList<>();
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery("Select id,foodname,image,price from orders",null);
        if(cursor.moveToNext()){
            while (cursor.moveToNext()){
                OrdersModel model = new OrdersModel();
                model.setOrderNumber(cursor.getInt(0)+"");
                model.setSoldItemName(cursor.getString(1));
                model.setOrderImage(cursor.getInt(2));
                model.setPrice(cursor.getInt(3)+"");
                orders.add(model);

            }
        }
        cursor.close();
        database.close();
        return orders;
    }
    public Cursor getOrderById(int id){
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery("Select * from orders where id =  "+id,null);
       if(cursor!=null)
           cursor.moveToFirst();

        return cursor;
    }

    public boolean upDateOrder(String name,String phone, int price, int image, String desc, String foodName, int quantity,int id){
        SQLiteDatabase database = getReadableDatabase();
        ContentValues values =new ContentValues();
        values.put("name", name);
        values.put("phone", phone);
        values.put("name", price);
        values.put("image", image);
        values.put("Description", desc);
        values.put("foodname", foodName);
        values.put("quantity", quantity);
        long row = database.update("orders",values,"id="+id,null);
        if(row <= 0){
            return false;
        }
        return true;
    }
    public int deleteOrder(String id){
        SQLiteDatabase database = this.getWritableDatabase();
        return database.delete("orders","id",null);
    }
}